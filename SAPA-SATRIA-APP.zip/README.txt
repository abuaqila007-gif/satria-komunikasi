SAPA SATRIA — aplikasi web mobile SATRIA

Berkas:
- index.html: antarmuka mobile-first.
- README.txt: panduan.
- satria_setup.sql: query pemeriksaan Realtime dan RLS.

Pemasangan:
1. Ekstrak ZIP.
2. Upload index.html ke hosting statis HTTPS.
3. Buka URL dari Chrome Android dan izinkan mikrofon/lokasi bila diperlukan.
4. Supabase Anonymous Sign-in harus aktif di Authentication > Providers > Anonymous.

Catatan:
- Aplikasi mengarah ke proyek Supabase SATRIA yang telah dikonfigurasi dengan publishable key frontend.
- Jangan pernah memasukkan service_role key ke file HTML.
- SOS menggunakan satria_sos_reports dengan kolom user_id, nickname, message, latitude, longitude, status, created_at.
- GPS mencoba upsert ke satria_locations dengan user_id, latitude, longitude. Jika kebijakan RLS atau skema berbeda, perlu penyesuaian.
- PTT WebRTC adalah prototipe browser dan perlu diuji di dua perangkat. Kinerja bergantung jaringan, izin browser, dan kebijakan Realtime. PTT saat layar terkunci/background tidak dijamin.
- Kanal baru saat ini hanya tersimpan pada antarmuka perangkat, belum persisten ke database.
