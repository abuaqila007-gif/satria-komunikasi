-- Jalankan hanya untuk memeriksa konfigurasi; jangan hapus kebijakan RLS yang ada.
SELECT tablename, policyname, cmd, roles, qual, with_check
FROM pg_policies
WHERE schemaname='public'
AND tablename IN ('satria_channels','satria_members','satria_locations','satria_sos_reports')
ORDER BY tablename, policyname;

SELECT tablename
FROM pg_publication_tables
WHERE pubname='supabase_realtime' AND schemaname='public'
ORDER BY tablename;
